#ifndef __BANK1_WORK_H__
#define __BANK1_WORK_H__

void test_bank1();

#endif
/* 
 * File:   buzzer.h
 * Author: lix
 *
 * Created on 2023��3��4��, ����10:10
 */

#ifndef BUZZER_H
#define	BUZZER_H

#include "globe.h"

void BuzzerProcess(void);


#ifdef	__cplusplus
extern "C" {
#endif



#ifdef	__cplusplus
}
#endif

#endif	/* BUZZER_H */


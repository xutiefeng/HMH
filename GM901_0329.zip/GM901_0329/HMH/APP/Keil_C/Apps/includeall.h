
#ifndef INCLUDEALL_H
#define INCLUDEALL_H

/////////////////////////////////��С��ܰ����ļ�///////////////////////////////

#include "..\Apps\ioConfig.h"
#include "..\Apps\globe.h"
#include "..\Apps\config.h"
////////////////////////////////////////////////////////////////////////////////
#include "..\Apps\bsp_Led.h"
#include "..\Apps\buzzer.h"
#include "..\Apps\bsp_eeprom.h"


#endif
    

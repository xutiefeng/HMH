#ifndef KEY_H
#define KEY_H

#include "globe.h"

void KeyProcess(void);
void KeyGaoYaSwitch(void);
void KeyRest(void);
void KeySelect(void);

#endif

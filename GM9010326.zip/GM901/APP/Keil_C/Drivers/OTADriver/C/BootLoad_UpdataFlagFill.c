#include "..\H\OTADriver.h"

unsigned char code UpdateSucceededFlagNumber[4] = {APP_UPDATA_FLAG_NUMBER};
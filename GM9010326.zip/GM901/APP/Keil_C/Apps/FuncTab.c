#include "FuncTab.h"




const volatile STSetVaue  ImageTemprertureTab[] = 
{
   {0xe1, 0},
	 {0xe2, 15},
	 {0xe3, 38},
	 {0xe4, 55},
	 {0xe5, 2},
	 {0xe6, 0},
	 {0xe7, -7},
	 {0xe8, -7},
	 {0xe9, -7},
	 {0xea, 5},//��ʾ EH
	 {0xeb, 1}, //��ʾ Eb
	 {0xec, 3}, //��ʾ �����汾��
};

volatile STSetVaue  TemprertureTab[] = 
{
   {0xe1, 0},
	 {0xe2, 15},
	 {0xe3, 38},
	 {0xe4, 55},
	 {0xe5, 2},
	 {0xe6, 0},
	 {0xe7, -7},
	 {0xe8, -7},
	 {0xe9, -7},
	 {0xea, 5},//��ʾ EH
	 {0xeb, 1}, //��ʾ Eb
	 {0xec, 3}, //��ʾ �����汾��
};


 //u8 dgg[2];










